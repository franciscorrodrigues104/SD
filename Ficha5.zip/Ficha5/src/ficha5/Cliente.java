/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ficha5;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author franc
 */
public class Cliente {

    public static void main(String[] args) {

        Scanner scann = new Scanner(System.in);

        System.out.println("Insira o IP");
        //String ip = scann.nextLine();
        System.out.println("Insira o porto");
        //int porto = scann.nextInt();
        
        

        try {

            Socket socket = new Socket("localhost", 5000);
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            
            

            boolean ativo = true;

            while (ativo) {

                System.out.println("1 - Insrerir nova acao");
                System.out.println("2 - Mostrar todas as acoes");
                System.out.println("3 - Apresentar valor atual e variacao de uma acao");
                System.out.println("4 - Eliminar uma acao");
                System.out.println("5 - Alterar valor de uma acao");
                System.out.println("6 - Sair do programa");
                
                
        
                
               int comando;
                
               
                try {
                    comando = Integer.parseInt(scann.next()); 
                    output.writeObject(comando);
                } catch (NumberFormatException e) {
                    System.out.println("Insira apenas numeros inteiros!");
                    continue; 
                }
                

               
                switch (comando) {
                    case 1:
                        System.out.println("Insira o nome da acao a adicionar:");
                        String nome = scann.next();
                        System.out.println("Insira o valor da acao:");
                        float valor = scann.nextFloat();

                        Acao acao = new Acao(nome, valor);

                        output.writeObject(acao);
                        output.flush();

                        int codigo = (int) input.readObject();
                        if (codigo == 0) {
                            System.out.println("Inserifdo com sucesso!");
                        } else {
                            System.out.println("Já exiuste um user com esse nome!");
                        }

                        break;

                    case 2:

                        ArrayList<Acao> lista = (ArrayList<Acao>) input.readObject();
                        Iterator<Acao> it = lista.iterator();
                        if (it.hasNext()) {
                            while (it.hasNext()) {
                                Acao a = it.next();
                                System.out.println(a.toString());
                            }
                        } else {
                            System.out.println("nao tem!");
                        }

                        break;

                    case 3:
                        System.out.println("Insira o nome da acao a apresentar os detelhes:");
                        String nomeAcao = scann.next();
                        output.writeObject(nomeAcao);
                        output.flush();

                        int temAcao = (int) input.readObject();

                        if (temAcao == 0) {

                            Acao acaoRecebida = (Acao) input.readObject();
                            System.out.println(acaoRecebida.toString());
                        } else {
                            System.out.println("Não tem acoes com o nome " + nomeAcao);
                        }
                        break;
                        
                    case 4:
                        System.out.println("Insira o nome da acao a remover:");
                        String nomeAcaoDel = scann.next();
                        output.writeObject(nomeAcaoDel);
                        output.flush();

                        int temAcaoDel = (int) input.readObject();

                        if (temAcaoDel == 0) {
                            System.out.println("Acao " + nomeAcaoDel + " eliminada com sucesso!");
                        } else {
                            System.out.println("Não tem acoes com o nome " + nomeAcaoDel);
                        }
                        break;

                    case 5:
                        
                         System.out.println("Insira o nome da acao a alterar:");
                        String nomeAcaoAltera = scann.next();
                        output.writeObject(nomeAcaoAltera);
                        output.flush();
                        
                         System.out.println("Insira o novo valor da acao:");
                            float novoValor = scann.nextFloat();
                            
                            output.writeObject(novoValor);
                            output.flush();

                        int temAcaoAltera = (int) input.readObject();

                        if (temAcaoAltera == 0) {
                            

                            System.out.println("Valor atual da acao atualizado com sucesso!");
                        } else {
                            System.out.println("Não tem acoes com o nome " + nomeAcaoAltera);
                        }
                        break;
                        
                    case 6:
                        ativo = false;
                        break;
                    default:
                        int verificaComando = (int) input.readObject();
                        if(verificaComando == 0){
                            System.out.println("Comando incorreto!");}
                        
                   
                }
            }

        } catch (Exception e) {
            
        }

    }

}
