package ficha5;

import java.io.Serializable;
import java.text.DecimalFormat;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author franc
 */
public class Acao implements Serializable{
    private String nome;
    private float valorInicial;
    private float valorAtual;
    
    public Acao(String nome, float valor){
    this.nome = nome;
    this.valorInicial = valor;
    this.valorAtual = valor;
    }
    
    public String getNome(){
    return this.nome;
    }
    
    public float getValorAtual(){
    return this.valorAtual;
    }
    
    public float getVariacao(){
    float variacao = ((this.valorAtual - this.valorInicial)/valorInicial) * 100;
    return variacao;
    }
    
    public void setValorAtual(float valor){
        this.valorAtual = valor;
        
    }
    
    public String toString(){
        
         DecimalFormat dfValor = new DecimalFormat("0.000");
    DecimalFormat dfVar = new DecimalFormat("0.00");
    
    return "Nome: " + this.nome +  " | Valor Atual: " + dfValor.format(this.valorAtual) + "€ | Variação: " + dfVar.format(this.getVariacao()) + "%";
    }
    
}
