package ficha5;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author franc
 */
class ThreadServidor extends Thread {

    Socket socket;

    ArrayList<Acao> listaAcoes;
    Iterator<Acao> it;

    public ThreadServidor(Socket socket, ArrayList<Acao> listaAcoes) {
        this.socket = socket;
        this.listaAcoes = listaAcoes;

    }

    @Override
    public void run() {
        try {
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());

            System.out.println("Cliente conectado!");
            System.out.println("IP remoto: " + socket.getInetAddress().getHostAddress());
            System.out.println("Porto remoto: " + socket.getPort());
            System.out.println("IP local: " + socket.getLocalAddress().getHostAddress());
            System.out.println("Porto local: " + socket.getLocalPort());

            boolean ativo = true;
            while (ativo) {
                boolean existe = false;

                int codigo = (int) input.readObject();
                System.out.print("Comando inserido pelo utilizador: " + codigo);
                
                

                switch (codigo) {
                    case 1:
                        System.out.println(" (Inseir uma acao)");
                        Acao acao = (Acao) input.readObject();

                        it = listaAcoes.iterator();
                        while (it.hasNext()) {
                            if (acao.getNome().equalsIgnoreCase(it.next().getNome())) {
                                output.writeObject(1);
                                existe = true;
                            }

                        }

                        if (!existe) {
                            this.listaAcoes.add(acao);
                            output.writeObject(0);
                        }

                        break;

                    case 2:
                        System.out.println(" (Listar todas as acoes)");

                        output.reset();
                        output.writeObject(listaAcoes);

                        output.flush();

                        break;

                    case 3:
                        System.out.println(" (Estatisticas de uma acao)");

                        String nomeAcao = (String) input.readObject();
                        Acao acaoEncontrada = null;
                        it = listaAcoes.iterator();
                        while (it.hasNext()) {
                            Acao atual = it.next();
                            if (nomeAcao.equalsIgnoreCase(atual.getNome())) {
                                existe = true;
                                acaoEncontrada = atual;
                                break;
                            }
                        }

                        if (existe) {
                            output.writeObject(0);
                            output.reset();

                            output.writeObject(acaoEncontrada);
                        } else {
                            output.writeObject(1);

                        }
                        break;

                    case 4:
                        System.out.println(" (Eliminar uma acao)");

                        String nomeAcaoDel = (String) input.readObject();
                        Acao acaoEncontradaDel = null;
                        it = listaAcoes.iterator();
                        while (it.hasNext()) {
                            Acao atual = it.next();
                            if (nomeAcaoDel.equalsIgnoreCase(atual.getNome())) {
                                existe = true;
                                acaoEncontradaDel = atual;
                                it.remove();

                                break;
                            }
                        }

                        if (existe) {
                            output.writeObject(0);
                            output.reset();

                        } else {
                            output.writeObject(1);

                        }
                        break;

                    case 5:
                        System.out.println(" (Alterar valor atual de uma acao)");

                        String nomeAcaoAltera = (String) input.readObject();
                        Acao acaoEncontradaAltera = null;
                        it = listaAcoes.iterator();
                        while (it.hasNext()) {
                            Acao atual = it.next();
                            if (nomeAcaoAltera.equalsIgnoreCase(atual.getNome())) {
                                existe = true;
                                acaoEncontradaAltera = atual;
                                float novoValor = (float) input.readObject();
                                atual.setValorAtual(novoValor);
                                break;
                            }
                        }

                        if (existe) {
                            output.writeObject(0);
                            output.reset();

                        } else {
                            output.writeObject(1);

                        }
                        break;
                        
                    case 6:
                        System.out.println(" (Sair)");
                        ativo = false;
                        break;
                        
                    default:
                        output.writeObject(0);
                            output.flush();
                        
                      

                }

            }
            socket.close();
            Servidor.decrementarThreads();
            

        } catch (Exception e) {
            
        }
    }

}
