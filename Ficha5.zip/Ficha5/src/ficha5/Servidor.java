package ficha5;

import java.net.ServerSocket;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Servidor {
    
    private static int numThreads;
    
    public static void incrementarThreads() {
        numThreads++;
        System.out.println("Thread " + numThreads + " iniciada -" + " Threads ativas: " + numThreads);
    }

    public static void decrementarThreads() {
        numThreads--;
        System.out.println("Thread " + (numThreads + 1) + " finalizada -" + " Threads ativas: " + numThreads);
    }

    public static void main(String[] args) {

        Scanner scann = new Scanner(System.in);
        System.out.println("Insira o porto:");
        int porto = scann.nextInt();
        
        ArrayList<Acao> listaAcoes = new ArrayList<>();


        try {
            
            ServerSocket serversocket = new ServerSocket(porto);

            while (true) {
                Socket socket = serversocket.accept();
                
                ThreadServidor thread = new ThreadServidor(socket, listaAcoes);
                thread.start();
                incrementarThreads();
            }
            
        } catch (Exception e) {
            System.out.println("Erro:" + e);
        }
    }
}
